#pragma once
#include "std.h"

class Camera
{
public:
	float cameraPosX = 0.0f;
	float cameraPosY = 0.0f;
	float cameraPosZ = -25.0f;
	float rotation = 0.0f;
	float self_rotation = 0.0f;
	float z_move = 0.0f;
	float x_move = 0.0f;

	glm::vec3 cameraPos = glm::vec3(cameraPosX, cameraPosY, cameraPosZ); //--- ī�޶� ��ġ
	glm::vec3 cameraDirection = glm::vec3(0.0f, 0.0f, 0.0f); //--- ī�޶� �ٶ󺸴� ����
	glm::vec3 cameraUp = glm::vec3(0.0f, 1.0f, 0.0f); //--- ī�޶� ���� ����
	glm::mat4 view = glm::mat4(1.0f);

	void Init_view(GLuint shaderProgramID);
	void Init_Projection(GLuint shaderProgramID);

};
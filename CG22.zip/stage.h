#pragma once
#include "std.h"

class Stage
{

public:
GLuint m_vao;

 void Init_And_Render(int model);

};